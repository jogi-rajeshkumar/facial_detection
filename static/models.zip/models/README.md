# face-api.js models

Uncompressed and quantized models used by [face-api.js](https://github.com/justadudewhohacks/face-api.js).